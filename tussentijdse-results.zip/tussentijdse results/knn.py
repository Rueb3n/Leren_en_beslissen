import csv
import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsClassifier

x_data_congo = pd.read_csv('New_Data_congo.csv', sep=',')
x_congo = np.asarray(x_data_congo)
#print x_congo

y_data_congo = pd.read_csv('userlist_congo.csv', sep=',')
y_congo = np.asarray(y_data_congo)

print y_congo.shape, x_congo.shape

neigh = KNeighborsClassifier(n_neighbors=1)
neigh.fit(x_congo, y_congo)


k,j = 1,0
for i in x_congo:
    if (neigh.predict([i]) == y_congo[k]):
        j += 1
    k += 1
    print (j)

# print (str(100*j/3200))
