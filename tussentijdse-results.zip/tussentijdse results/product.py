import json


class productdata:
    
    def __init__(self):
        self.productList = []
        # open file
        with open('products.json') as json_data:
            
            # laad data
            self.data = json.load(json_data)
            
            # neem alleen relevante data
            for element in self.data:
                soort = element["name"]
                iD = element["_id"]["$oid"]
                typeId = element["type"]["id"]
                self.productList.append({"_id":iD,"soort":soort,"type":typeId})\
                
    def checkProductId(self, productId):
        for element in self.productList:
            if (element["_id"] == productId):
                return element
                
    def checkProductName(self, naam):
        for element in self.productList:
            if (element["soort"] == naam):
                return element
            
    def giveProducts(self):
        for element in self.data:
            print (element["name"])


        
    
    
    