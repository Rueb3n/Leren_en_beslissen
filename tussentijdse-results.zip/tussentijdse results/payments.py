#!/usr/bin/env python3

import json
import time
import numpy as np
import product
import datetime

productList = []
productdata = product.productdata()

# open output files
f_spec = open("data/New_Data_spec.csv", "w")
f_spec.write("kwartier,weekdag,bier,fris,speciaalBier,ijsje,wijn\n")
f_congo = open("data/New_Data_congo.csv", "w")
f_congo.write("kwartier,weekdag,bier,fris,speciaalBier,ijsje,wijn\n")
g_spec = open("data/userlist_spec.csv", "w")
g_spec.write("user_id\n")
g_congo = open("data/userlist_congo.csv", "w")
g_congo.write("user_id\n")

# producten
CK = ["CK - Bier", "CK - Speciaal bier", "CK - Ijs", "CK - Fris",  "CK - streep €1", "CK - streep €10", "CK - Streep"]
HOK = ["HOK - Bier", "HOK - Fris", "HOK - Het brakke uiltje", "HOK - Flesje wijn (0,25 l)"]

# exporterende databases
HOK_database = []
CK_database = [] 

def bouwDatabase(lijst, productKeyGezocht, x_waardes, y_waardes): 

    # open file
    with open('payments.json') as json_data:
        
        # laad data
        data = json.load(json_data)
        
        # users per transactie komen hier als de te voorspellen waarde
        Y_vector = []
        
        # loop door transacties
        for element in data:
            # probeer het eerste product te ontravelen
            try:
                productId = element["products"][0]["_id"]["$oid"]
            except: 
                productId = 0
            # neem alleen relevante data
            if (productId == productKeyGezocht):
                
                # initieer tellers
                bier, fris, speciaalBier, ijsje, wijn = 0,0,0,0,0
                
                # loop door gekochte producten
                for drankje in element["products"]:
                    
                    # vind productsoort
                    productId = drankje["_id"]["$oid"]
                    productnaam = productdata.checkProductId(productId)["soort"]
                    
                    # tel aantal
                    if (productnaam == "CK - Bier" or productnaam == "HOK - Bier" or productnaam =="CK - streep €1" or productnaam == "CK - Streep"):
                        bier += 1
                    elif (productnaam == "CK - Fris" or productnaam == "HOK - Fris"):
                        fris += 1
                    elif (productnaam == "CK - Speciaal bier" or productnaam == "HOK - Het brakke uiltje"):
                        speciaalBier += 1
                    elif (productnaam == "CK - Ijsje"):
                        ijsje += 1
                    elif (productnaam == "HOK - Flesje wijn (0,25 l)"):
                        wijn += 1
                        print("wijn")
                    elif (productnaam == "CK - streep €10"):
                        bier += 10
                
                # bepaal user
                Y_vector.append({"user" : element["state"]["by"]["$oid"]})
                y_waardes.write(str(element["state"]["by"]["$oid"])+"\n")
                
                # bepaal tijd transactie
                tijd = element["state"]["on"]["time"]
                hour, minute = (int(x) for x in tijd.split(':'))
                tijd = (int(hour)*60+int(minute))/15
                
                # bepaal dag in de week
                weekdag = element["state"]["on"]["date"]
                day, month, year = (int(x) for x in weekdag.split('/'))    
                weekdag = datetime.date(year, month, day).weekday()
                
                # schrijf z waardes weg
                x_waardes.write(str(tijd)+","+str(weekdag)+","+str(bier)+","+str(fris)+","+str(speciaalBier)+","+str(ijsje)+","+str(wijn)+"\n")
                lijst.append({"tijd":tijd, "weekdag":weekdag, "bier" : bier, "fris" : fris, "speciaalBier" : speciaalBier, "ijsje" : ijsje, "wijn" : wijn})
                
    return lijst, Y_vector

# bouw spectrum database
print ("spectrum objecten: ")
for product in HOK:
    print(productdata.checkProductName(product))
    bouwDatabase(HOK_database, productdata.checkProductName(product)["_id"], f_spec, g_spec)

# bouw congo database    
print ("congo objecten: ")
for product in CK:
    print(productdata.checkProductName(product))
    bouwDatabase(CK_database, productdata.checkProductName(product)["_id"], f_congo, g_congo)
